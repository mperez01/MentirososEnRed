"use strict";

module.exports = {
  mysqlConfig:{
    // Ordenador que ejecuta el SGBD
    host: "localhost",
  
    // Usuario que accede a la BD
    user: "root",
  
    // Contraseña con la que se accede a la BD
    password: "",
  
    // Nombre de la base de datos
    database: "mentiroso"
  },
  //Puerto de escucha
  port:3000

}